
<html>
    <head>
		<title>Sign up </title>
		<style>
                 body {
                 background-image: url('Sign Up Pic.jpg');
                 background-repeat: no-repeat;
                 background-attachment: fixed; 
                 background-size: 100% 100%;
             }

        
           
             </style>
	</head>
	
		<script src="Email Validate.js"></script>
		
        
           
		<center><img src="Modified.png"></center>
            <body onload='document.form1.text1.focus()'>
		<center>
                <div class="login-box">
                    <h1>Sign Up</h1>
                    <div class="textbox">
					 
                        <i style="font-size:24px;color: white" class="fa">&#xf007;</i>
                        <form name="form2" action="Action.php" onsubmit="return(ValidateEmail())==1)">
                        <input type='text' placeholder="Enter Mail Id" name="mailid" value="">  <br>  
                    </div>

                    <div class="textbox">
                        <i class="fa fa-lock" style="font-size:25px;color:white"></i>
                        <form name="form1" action="#">
                        <input type="password" placeholder="Password" name="password" value="">
                    </div>
			<br><br>
                    <button class="submit" type="submit" > Sign Up </button><br><br>
<strong> <h2>Contact US On<br>
<a href="https://www.instagram.com/myntra/?hl=en" target="_blank"> Instagram </a> <br><br>
              </center>      
            </html>
        </html>