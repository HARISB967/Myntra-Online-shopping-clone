<html>
<head>
<title> Table Contents </title>
</head>
<style>
body{background: url('CR.jpg');
h1 font-family: Segoe UI;
th font-family: Segoe UI;
 background-repeat: no-repeat;
background-size:100%;
</style>
<body style="background-color:HotPink">
<center>
<img src="Modified.png">
<h1 > MYNTRA - Online Shopping Platform  </h1>
</center>>


<table border="5" width="450" height="40px" cellspacing="20" align="center">
<caption><h2>      SELECT THE REQUIRED CATEGORY </caption></h1>
<tr bgcolor = "HotPink">
  <tr>
    <th><a href="Men.php" >MEN</a></th>
    <th><a href="Women.php">WOMEN</a></th>
    <th><a href="Kids.php">KIDS</a></th>
    <th><a href="Home.php">HOME AND LIVING</a></th>
  </tr>
<tr>
</table><br><br><center>
<h2><strong> To Go Back TO Home Page - Click Below </h2><br>
<a href="HOME PAGE.php" target="_blank"> HOME PAGE <br></a>
<br>
<center>
<strong><h3> Contact US On</h3> 
<a href="https://www.instagram.com/myntra/?hl=en" target="_blank"> Instagram </a>
</body>
</html>