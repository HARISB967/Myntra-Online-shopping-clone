<html>
<head>
<title> Bottomwear </title>
</head>
<body style="background-color:#33C6FF">

<hs> 
<b>Price: Rs.700 <br>Size: 38<br> Women Blue Skinny Fit High-Rise Clean Look Stretchable Jeans </hs><br>
<center><img src="Women Jeans.jfif"height="500" width="300"> </a><br/><br><br>
<button class="button btnone"><a style="text-decoration:none" color="white" href="online transaction.php"><b>BUY NOW</b></button></center>
<marquee><img src="Modified.png"> </marquee>
</body>
</html>