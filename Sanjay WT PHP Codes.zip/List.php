<html>
<head>
<title> LIST OF PRODUCTS </title>

</head>
<body style="background-color:powderblue;">
<h2> MEN </h2>
<ul><a href="Details2.php" target="f3"> Topwear  </a> 
<br><br>
<a href="Details3.php" target="f3"> Bottomwear </a> 
</ul>
<h2>  WOMEN  </h2> 
<ul><a href="Details4.php" target="f3"> Topwear </a>
<br><br>
<a href="Details5.php" target="f3"> Bottomwear </a> 
</ul> 
<h2> KIDS </h2>
<ul><a href="Details6.php" target="f3"> Topwear </a>
<br><br>
<a href="Details7.php" target="f3"> Bottomwear </a>
</ul>
<h2> HOME AND LIVING </h2>
<ul><a href="Details8.php" target="f3"> Lights </a>
<br><br>
<a href="Details9.php" target="f3"> Decoration Items </a>
<br></ul>

<h2>To Go Back: <a target="_blank" href="HOME PAGE.php"> Home Page</a></h2>
 </ul>
</body>
</html>
