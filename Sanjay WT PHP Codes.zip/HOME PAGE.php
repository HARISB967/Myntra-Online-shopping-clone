<html>
<head>
	<link rel="stylesheet" href="C:\Users\Sanjay\Desktop\Msc\Sem 2\Web Tech\External CSS.css">
<style>
body {
  background: url(twitter-patterns-3.jpg);
  background-size:100%;
 
  
  }
</style>
</head>
	
<center>
<body background="HPic.jpg">

<img src="Modified.png"> 
<h1>HOME PAGE<br> <br><br><br></h1>

<h2><a href="Signup Myntra.php"> Sign Up <br><br></a>

<a href="List of Products.php"> List of Products <br><br></a>

<a href="Customer Reviews.php">Customer Review<br><br></a>

<a href="Order Placing.php">To Shop<br><br></a>

<a href="About Us.php"> About Us<br><br></a></h2>

</center>
<marquee><hs> <b>Thanking for Visiting Myntra </hs> </marquee>

</h2>
</body>
</html>