<html>
<head>
<title> Title </title>

</head>

<center>
<body style="background-color:HotPink">

<img src="Modified.png">
<h1 > MYNTRA - Online Shopping Platform  </h1>
</center>
</body>
</html>
