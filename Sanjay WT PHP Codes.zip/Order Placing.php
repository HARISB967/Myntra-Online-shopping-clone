<html>
<head>
<style type="text/css">
	body{
	background-image: url(BG.jpg);
	background-repeat:no-repeat;
	background-attachment:fixed;
	background-size:100%100%;
	opacity:0.5;
	}
</style>
<title>Order Placing </title>
</head>
<frameset rows="25,75">
	<frame src="Title.php" name="PRODUCTS">
	<frameset cols="20,80">
		<frame src="List.php" name="f2">
		<frame src="Final.jpg" name="f3">	
	</frameset>
</frameset>
</body>
</html>
