<html>
<head>
<title> Topwear </title>
</head>
<body style="background-color:#33C6FF;">


<hs> 
<b>Price: Rs.700 <br> Age Group: 10-13yrs<br> Girls Red Georgette Polka Dot Top </hs><br>
<center><img src="Kid Top.jfif"></a> <br><br>
<button class="button btnone"><a style="text-decoration:none" color="white" href="online transaction.php"><b>BUY NOW</b></button></center>
<marquee><img src="Modified.png"> </marquee>
</body>
</html>
