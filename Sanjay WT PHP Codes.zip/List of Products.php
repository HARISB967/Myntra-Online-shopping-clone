<html>
<head>
<title> INDEX</title>
</head>
<body background="Picture.jpg">

 
<h1 style="font-family: Century Gothic"><center><img src="Modified.png"><br> MYNTRA - Online Shopping Platform </center> </h1>
<center>
 
<h2 style="font-family: Segoe UI"> PRODUCTS AT MYNTRA </h2>
<strong> Contact US On
<a href="https://www.instagram.com/myntra/?hl=en" target="_blank"> Instagram </a> <br><br>
<hs style="font-family: Segoe UI;font-size: 20px"><a href="#MEN"> MEN</a>   <br>
<hs style="font-family: Segoe UI;font-size: 20px"><a href="#WOMEN"> WOMEN </a> <br>
<hs style="ont-family: Segoe UI;font-size: 20px"><a href="#KIDS"> KIDS </a> <br>
<hs style="font-family: Segoe UI;font-size: 20px"><a href="#HOME"> HOME AND LIVING </a>  <br>

<br>

<br>
<hs style="background-color:PowderBlue;font-family: Segoe UI;font-size: 20px"><a name="MEN"> MEN </a>  <br>
<hs>
<ul>
<li><hs style="font-family: Segoe UI"> Topwear </li><br>
<li><hs style="font-family: Segoe UI"> Bottomwear </li><br>
<li><hs style="font-family: Segoe UI"> Indian and Festive Wear </li><br>
<li><hs style="font-family: Segoe UI"> Sports and Active Wear </li><br>
<li><hs style="font-family: Segoe UI"> Accessories </li><br>
</hs>
</ul>
<hs style="background-color:PowderBlue;font-family: Segoe UI;font-size: 20px"><a name="WOMEN"> WOMEN </a> <br>
<hs>
<ul>
<li><hs style="font-family: Segoe UI"> Indian and Fusion Wear </li><br>
<li><hs style="font-family: Segoe UI"> Western Wear </li><br>
<li><hs style="font-family: Segoe UI"> Beauty and Personal Care </li><br>
<li><hs style="font-family: Segoe UI"> Sports and Active Wear </li><br>
<li><hs style="font-family: Segoe UI"> Accessories </li><br>
</hs>
</ul>
<hs style="background-color:PowderBlue;font-family: Segoe UI;font-size: 20px"><a name="KIDS"> KIDS </a> 
</hs>
<hs>
<ul>
<li><hs style="font-family: Segoe UI"> Boys Clothing </li><br>
<li><hs style="font-family: Segoe UI"> Girls Clothing </li><br>
<li><hs style="font-family: Segoe UI"> Boys and Girls Footwear </li><br>
<li><hs style="font-family: Segoe UI"> Infants </li><br>
<li><hs style="font-family: Segoe UI"> Kids Accessories </li><br>
</hs>
</ul>
<hs style="background-color:PowderBlue;font-family: Segoe UI;font-size: 20px"><a name="HOME"> HOME AND LIVING </a> 
</hs>
<hs>
<ul>
<li><hs style="font-family: Segoe UI"> Bed Linen and Furnishing </li><br>
<li><hs style="font-family: Segoe UI"> Flooring </li><br>
<li><hs style="font-family: Segoe UI"> Lamps and Lighting </li><br>
<li><hs style="font-family: Segoe UI"> Home Decor </li><br>
<li><hs style="font-family: Segoe UI"> Kitchen and Table </li><br>
</hs>
</ul>
</center>
</body>
</html>