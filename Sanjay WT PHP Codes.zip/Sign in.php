<html>
    <head>
     
        <title>Sign up </title>
       
             
             <style>
                 body {
                 background-image: url('Sign Up Pic.jpg');
                 background-repeat: no-repeat;
                 background-attachment: fixed; 
                 background-size: 100% 100%;
             }
             </style>
            </head>
            <body>
		<center>
                <div class="login-box">
                    <h1>Sign IN</h1>
                    <div class="textbox">
                        <i style="font-size:24px;color: white" class="fa">&#xf007;</i>
                        <form name="form1">
                        <input type='text' placeholder="Enter Mail Id" name="mailid" value="">    
                    </div>

                    <div class="textbox">
                        <i class="fa fa-lock" style="font-size:25px;color:white"></i>
                        <form name="form1">
                        <input type="password" placeholder="Password" name="pw" value="" >
                    </div>
                    
					<a href="HOME PAGE.php" target="_blank">Home Page</a> 
              </center>      
            </html>
        </html>
