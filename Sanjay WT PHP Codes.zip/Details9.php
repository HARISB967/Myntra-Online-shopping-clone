<html>
<head>
<title> Decoration Items </title>
</head>
<body style="background-color:#33C6FF">

<hs>
<b> Price: Rs.700 <br> Set of 5 White & Blue Printed Framed Wall Art</hs><br>
<center><img src="Home 2 (1).jfif" height="500" width="300"> </a><br/><br><br>
<button class="button btnone"><a style="text-decoration:none" color="white" href="online transaction.php"><b>BUY NOW</b></button>
<marquee><img src="Modified.png"> </marquee>
</body>
</html>