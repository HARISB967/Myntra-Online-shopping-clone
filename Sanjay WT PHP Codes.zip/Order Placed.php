<html>
<head>
<link rel="stylesheet" href="C:\Users\Sanjay\Desktop\Msc\Sem 2\Web Tech\External CSS.css">
<title>
Order Placement
</title>
</head>
<body align="center">
<style>
                 body {
                 background-image: url('Sales Pic.jpg');
                 background-repeat: no-repeat;
                 background-attachment: fixed; 
                 background-size: 100% 100%;
             }
             </style>
<h2> Your Order Has Been Successfully Placed! <br>
Thanks for Shopping at Myntra
<br><br><br>
Click Below to Go Back to Main Page
<br><br>
<a href="HOME PAGE.php" target="_blank"> HOME PAGE <br><br></a>
<h2> To Print The Bill For The Order, Click Below <br><br>
<a target="_blank" href="Bill.php" >Print Bill<br></a></h2>
</body>
</html>

